$(".next").click(function () {
    alert("next clicked")
})