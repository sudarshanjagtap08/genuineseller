
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row heading-bg">
        <div class="col-lg-12">
            <h5 class="txt-dark">All Buyer Information</h5>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-default card-view">
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <?php if(session('status')): ?>
                        <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
                        <?php endif; ?>
                        <div class="table-wrap">
                            <div class="table-responsive">
                                <table id="example" class="table table-hover display  pb-30">
                                    <thead>
                                        <tr>
                                            <th>Action</th>
                                            <th>Buyer Id</th>
                                            <th>Name</th>
                                            <th>Address</th>
                                            <th>Email Id</th>
                                            <th>Mobile Number</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $user->buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="btn-group">
                                                        <div class="addMore" title="Edit Data">
                                                            <a  href="<?php echo e(url('buyer/information/edit/'.$user->id)); ?>" class="btn btn-primary btn-sm" style="padding: 2px 7px;"><i class="fa fa-pencil"></i></a>
                                                        </div>
                                                        <!-- <div class="addMore" title="View Data">
                                                            <a href="#" class="btn btn-danger btn-sm" style="padding: 2px 6px;"><i class="fa fa-eye"></i></a>
                                                        </div> -->
                                                    </div>
                                                </td>
                                                <td><?php echo e($buyer->buyer_documentid); ?></td>
                                                <td><?php echo e($user->name); ?></td>
                                                <td><?php echo e($buyer->address); ?></td>
                                                <td><?php echo e($user->email); ?></td>
                                                <td><?php echo e($buyer->mobilenumber); ?></td>
                                                <?php if($user->status == 1): ?>
                                                <td>Verify</td>
                                                <?php else: ?>
                                                <td>UnVerify</td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\genuinesseller\resources\views/information/information_index.blade.php ENDPATH**/ ?>